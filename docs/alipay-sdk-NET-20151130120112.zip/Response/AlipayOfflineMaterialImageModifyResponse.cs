using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMaterialImageModifyResponse.
    /// </summary>
    public class AlipayOfflineMaterialImageModifyResponse : AopResponse
    {
    }
}

using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMaterialImageQueryResponse.
    /// </summary>
    public class AlipayOfflineMaterialImageQueryResponse : AopResponse
    {
    }
}

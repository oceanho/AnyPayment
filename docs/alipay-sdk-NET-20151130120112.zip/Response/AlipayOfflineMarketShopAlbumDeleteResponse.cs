using System;
using System.Xml.Serialization;

namespace Aop.Api.Response
{
    /// <summary>
    /// AlipayOfflineMarketShopAlbumDeleteResponse.
    /// </summary>
    public class AlipayOfflineMarketShopAlbumDeleteResponse : AopResponse
    {
    }
}
